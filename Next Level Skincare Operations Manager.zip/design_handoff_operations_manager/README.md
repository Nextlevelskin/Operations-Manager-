# Handoff: Next Level Skincare — Operations Manager

## Overview
A mobile-first operations app for a solo founder running two income streams (a skincare brand + independent-contractor massage therapy). It reduces mental load by centralizing outreach tracking, follow-up reminders, AI-drafted follow-up emails, a weekly task view, a content calendar, and settings (reminders, follow-up cadences, Google Sheets import, Gmail connection).

Core principle from the founder: **"Open the app and know what to do — don't make me remember anything."** Keep it calm, simple, and uncluttered over flashy.

## Platform target — IMPORTANT (read first)
The founder works from **both her phone and her laptop** and needs the **same app, with the same data, on both**. The recommended build is a **Progressive Web App (PWA)** — one codebase that runs in the browser and installs to the home screen / desktop:

- **Phone (primary):** open the site in Safari/Chrome → "Add to Home Screen." It then launches full-screen with an app icon and supports push notifications. No App Store / Play Store submission required.
- **Laptop/desktop:** open in any browser, or install as a desktop app (Chrome/Edge "Install app"). The layout must be **responsive** — the designs in this bundle are phone-width (≈392px); on wider screens, expand to a centered single column (≈420–480px max) or a comfortable two-pane layout (list + detail). Do not just stretch phone UI to full desktop width.
- **One account, synced data:** contacts, follow-ups, settings, and content must live server-side (a hosted database) and sync across devices automatically — editing on the laptop shows instantly on the phone.

Why a PWA (not native iOS/Android): it's one codebase for phone + desktop, far cheaper/faster for a solo founder, installs without app stores, and still gives an app icon, full-screen, offline shell, and push notifications. A native app is **not** required to meet "works on my phone and my computer."

### Suggested stack to deliver the above
- **Front end:** React (Vite or Next.js) as a PWA — responsive layout, installable manifest + service worker, Web Push for reminders. (If the team strongly prefers native later, React Native/Expo can reuse the same backend — but ship the PWA first.)
- **Back end:** Node/TypeScript API with a hosted database (e.g. Postgres/Supabase or Firebase). Handles auth, the contacts/tasks/content data, Gmail + Google Sheets OAuth, scheduled reminder jobs, and the AI draft endpoint.
- **Auth:** sign in with Google (the founder already uses Google Workspace) — also covers the Gmail/Sheets permission scopes.
- **Hosting:** any standard host (Vercel/Netlify for the front end, a small managed backend + DB). HTTPS is required for PWA install + push.

## How the founder will actually run it (plain English — keep this true in the build)
1. The developer deploys it to a web address (e.g. `app.nextlevelskincare.ca`).
2. On her **laptop**, she visits that link and clicks "Install" — it gets a desktop icon and its own window.
3. On her **phone**, she visits the same link and taps "Add to Home Screen" — it gets an app icon and sends reminder notifications.
4. She signs in with Google once on each device; everything stays in sync because the data is in the cloud.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working, clickable prototype showing the intended look and behavior. **They are not production code to copy directly.** The single file `Operations Manager.dc.html` is authored in a small in-house template runtime (a custom `<x-dc>` web component with a `class Component extends DCLogic` logic class); that runtime is **not** something to reproduce.

The task is to **recreate these designs in the target codebase's environment** using its established patterns and libraries. Per the **Platform target** section above, the recommended build is a **responsive React PWA** front end with a small Node/TS backend (OAuth, scheduled reminders, AI drafting, synced database). Treat the HTML/logic purely as the spec for UI and behavior.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions are all intentional and specified below. Recreate the UI to match, using the codebase's component primitives. Exact hex values, font sizes, and copy are given.

---

## Design Tokens

### Colors
| Token | Hex | Usage |
|---|---|---|
| Brand green (primary) | `#305536` | Primary buttons, active tab, headings accents, selected states |
| Green deep (text/ink on green gradient) | `#2B3A2E` | Primary text, dark end of header gradient |
| Green mid | `#3C6450` | Success ticks, "Reminder on", secondary green |
| Cream page bg | `#F5F0E6` | App background (inside phone) |
| Card surface | `#FFFDF8` | Cards, list rows, panels |
| Warm panel | `#F3ECDD` | Notes block, subtle fills |
| Tab bar bg | `#FBF8F0` | Bottom tab bar |
| Muted label | `#8A8576` | Section labels, secondary text |
| Faint label | `#A89F8C` | Eyebrow/uppercase labels, timestamps |
| Placeholder/inactive | `#B3AC9C` | Inactive tab icons, skipped mapping, search placeholder |
| Body subtext | `#6E7268` | Sub-headlines, descriptions |
| Body text | `#45493E` / `#5E6253` | Notes, history text |
| On-green text | `#EDF1E8` / `#F2F5ED` | Text on green surfaces |
| Soft green tint | `#DFEAE1` / `#E8F0E9` | Avatar/success circle bg, icon chip bg |

### Category accent colors (contact type → bg / text / dot)
| Category | Chip bg | Chip text | Dot |
|---|---|---|---|
| Wholesale | `#EFE6D4` | `#8A6A33` | `#B59243` |
| Clinical | `#DEE8E1` | `#3C6450` | `#3C6450` |
| Partnership | `#ECE0E5` | `#7B566A` | `#9A7488` |
| Massage | `#F0E3DD` | `#9C5E4C` | `#B5715C` |

### Urgency text colors
- Overdue: `#B05A3C`
- Due today: `#305536`
- Due soon / later: `#9A9486`

### Content post platform chips
- Instagram: bg `#ECE0E5`, text `#7B566A`
- TikTok: bg `#E0E4EA`, text `#475569`
- Email: bg `#DEE8E1`, text `#3C6450`

### Content post status chips
- Ready: bg `#DFEAE1`, text `#3C6450`
- Scheduled: bg `#EFE6D4`, text `#8A6A33`
- Draft: bg `#F0E3DD`, text `#9C5E4C`
- Idea: bg `#ECE7DA`, text `#8A8576`

### Typography
- **Display / headings:** `Cormorant Garamond`, weight 600 (also 500). Used for screen titles ("Good morning, Sarah.", "Settings", "Content", numbers in stat pills). Sizes range 23–33px on screen titles, larger for the greeting.
- **UI / body:** `Mulish`, weights 400/500/600/700. All labels, body, buttons, chips.
- Eyebrow labels: 11–12px, weight 700, `letter-spacing: 1.2–1.6px`, `text-transform: uppercase`, color `#8A8576`/`#A89F8C`.
- Body copy: 13.5–15px, line-height ~1.5.
- Minimum touch target 44px.

### Radii & shadows
- Cards/panels: `border-radius: 16–18px`
- Pills/buttons: `11–16px`; chips `7–9px`; small tags `8–12px`
- Avatars: `13–22px` (rounded square) or `50%` (circles)
- Card shadow: `0 2px 10px -6px rgba(40,50,40,.25)`
- Primary button shadow: `0 10px 24px -10px rgba(48,85,54,.7)`
- Phone frame shadow: `0 40px 90px -30px rgba(40,50,40,.55)`

### Spacing
- Screen horizontal padding: 22px
- Card inner padding: 13–16px
- Gaps between list items: 9–11px; between sections: 22–28px

---

## Screens / Views

The app is a single phone-framed surface (design size 392×838 device, 44px inner radius). A persistent **bottom tab bar** (Today / Week / Contacts / Content) shows on the four main screens; Detail, Draft, Sent, Settings, and the Import flow are pushed views without the tab bar.

### 1. Today (home)
- **Purpose:** Open in the morning and immediately see who needs a follow-up, sorted by urgency.
- **Layout (top→bottom):**
  - Header row: brand logo (`assets/logo.png`, height 21px) left; gear icon (→ Settings) + circular avatar with founder initial right.
  - Eyebrow date ("THURSDAY · JUNE 25"), Cormorant greeting "Good morning, {firstName}.", one-line subtext summarizing how many people are waiting.
  - Two stat pills: green pill = follow-up count; cream pill = tasks today.
  - "NEEDS YOU TODAY" section: cards for each overdue/due-today contact, sorted overdue-first then by most-overdue. Each card: avatar (category-colored initials), name, org, urgency label (right, colored), category chip, and a green **Draft** button (sparkle icon) that jumps straight to the AI draft for that contact.
  - Empty state (when nothing due): green check circle, "You've cleared today.", reassuring subtext, and a product hero image (`assets/product-hero.png`).
  - "COMING UP" section: compact list of soon-due contacts (colored dot, name, org, due label). Controlled by a `showComingUp` flag.
- **Copy:** Greeting subtext when items exist: "{n} people are waiting to hear from you. Start at the top." When clear: "You're all caught up. Enjoy the calm."

### 2. Week
- **Purpose:** Everything due this week across all categories in one place.
- **Layout:** Title "This week" + range eyebrow. Day-grouped lists (Today, Tomorrow, named dates). Each task row: a 24px checkbox (tap to toggle done → green fill + strikethrough label), label, and a category chip (Follow-up / Content / Massage / Finance / Event). Follow-up tasks link to the relevant contact detail.
- **Categories carry across both income streams** — tasks are tagged, not separated into different sections.

### 3. Contacts (CRM list)
- **Purpose:** Browse/search the full contact book.
- **Layout:** Title "Contacts", a search field (visual only in prototype), a horizontally-scrolling filter chip row (All / Wholesale / Clinical / Partnership / Massage; active chip = green), then contact rows sorted by urgency (overdue→today→soon→none). Each row: category-colored avatar initials, name, "{org} · {category}", urgency label on the right.

### 4. Contact Detail
- **Purpose:** See full history and update status; entry point to drafting an email.
- **Layout:** Back button. Centered avatar (rounded square, category color), name (Cormorant), org, category chip. Three action tiles: Call / Email / Schedule. A 2×2 facts grid: Status, Next follow-up (red if overdue), First contact, Last contact. "QUICK UPDATE" status chips (single-select, green when active): "Called — left voicemail", "Responded — in progress", "Booked / confirmed", "Not a fit right now". "HISTORY" vertical timeline (dated entries). "NOTES" warm panel. Sticky bottom CTA: **"Draft follow-up email"** (green, sparkle icon).

### 5. AI Email Draft
- **Purpose:** Generate an editable follow-up email in the founder's voice, pulling name/org/history automatically.
- **Layout:** Back. Title "Follow-up draft" + "Written in your voice from {org}'s history" with a sparkle icon. For non-massage contacts, a 52px product jar thumbnail (`assets/product-jar.png`) sits to the right of the title. Tone segmented control: **Warmer / Shorter / Direct** (changes both subject and body). Email card: To (name + email, read-only), Subject (editable input), Body (editable multi-line textarea, min-height ~270px). Helper line: "Review before sending — nothing sends automatically." Sticky CTA: **"Send & log to CRM"** (paper-plane icon).
- **Draft generation:** Each contact has a `topic`, a long `followBody`, and a short `followShort`. Tone presets:
  - *Warmer:* subject "Checking in on the {topic}"; warm, gentle body using `followBody`, sign-off "Warmly, {founder} / {brand}".
  - *Shorter:* subject "Quick follow-up — {topic}"; brief body using `followShort`; "Thanks so much,".
  - *Direct:* subject "Next steps — {topic}"; concise body using `followShort` + a next-steps line; "Best,".
- **Never auto-sends.** Always editable before sending.

### 6. Sent confirmation
- Green check circle, "Sent to {firstName}.", and an auto-log summary card with three ticks: "Last contact updated to **today**", "Status set to **Awaiting reply**", "Next follow-up set for **{date}**". Button "Back to today". This is the moment that closes the loop and removes the contact from "needs you today".

### 7. Settings
- **Reach:** gear icon in Today header. Title "Settings", subtitle "Set it once. The app remembers, so you don't have to."
- **REMINDERS section** (card): Push notifications toggle (default on), Email reminders toggle (default off), Daily digest time segmented control (7 AM / 8 AM / 9 AM, default 8 AM). Below: a **notification preview** card on a green gradient showing how the morning push looks ("3 follow-ups need you today. Bloom Apothecary is 4 days overdue.").
- **FOLLOW-UP CADENCE section:** intro "Default time before a contact resurfaces. The app sets each 'next follow-up' date for you automatically." Then per-category stepper rows (– / value / +): Wholesale (default 1 week), Clinical / institutional (default 2 weeks), Partnership (default 1 week), Massage contracting (default 10 days). Brand categories step in 7-day increments and display as weeks; Massage steps in 1-day increments and displays as days. Clamp 2–60 days.
- **IMPORT & ACCOUNTS section:** "Import from Google Sheets" row (→ launches Import flow), "Gmail — Connected" row with a green status dot. Footnote on data privacy.

### 8. Google Sheets Import (4-step flow)
Pushed flow with a 3-segment progress bar and step label ("Step 1 of 3" … "Done"), back navigation at each step, and a sticky bottom CTA.
- **Step 1 — Choose spreadsheet:** "Connected as sarah@nextlevelskincare.ca." Selectable sheet cards (name + "{n} rows · edited …"), radio check on the selected one. CTA "Continue".
- **Step 2 — Match columns:** "We matched these automatically from {sheet}." A green confirmation banner "{x} of {n} columns matched automatically." Mapping rows: app field (with "Required" tag for Name/Email) → an arrow → the detected sheet column (tap to cycle alternatives, including "— skip —"), with a sample value beneath. CTA "Looks right — continue".
- **Step 3 — Ready to import:** Two stat pills ("47 contacts found", "9 need follow-up soon"). Reassurance card: follow-up dates computed from cadence settings; existing contacts updated not duplicated; one-way read (sheet never changed). CTA "Import 47 contacts".
- **Step 4 — Done:** Success check, "47 contacts imported.", "9 need you this week", buttons "See my contacts" / "Back to today".

### 9. Content Calendar (tab)
- **Purpose:** Plan social posts ahead with reminders to actually post.
- **Layout:** Title "Content" + month. "Post today" reminder banner (green) with bell icon and "Open". Posts grouped "This week" / "Next week". Each post card: 58px thumbnail (product jar image for product posts, list glyph otherwise), platform chip, scheduled time, title, status chip, and a per-post **reminder toggle** (bell + "Reminder on"/"Remind me", green when on). A dashed "Plan a post" add affordance at the bottom.

---

## Interactions & Behavior
- **Navigation:** tab bar switches Today/Week/Contacts/Content. Cards push to Detail; Detail → Draft → Sent → back to Today. Gear → Settings → Import flow. All pushed views have a Back control.
- **Draft button on Today** deep-links straight into the AI draft for that contact (skips Detail).
- **Tone switch** regenerates subject + body instantly from presets.
- **Send & log** marks the follow-up done (removes from "needs you today"), sets status to "Awaiting reply", advances next-follow-up date, shows Sent confirmation.
- **Quick status chips** single-select and persist on the contact.
- **Week checkboxes** toggle done (fill + strikethrough).
- **Cadence steppers** clamp 2–60 days; brand categories ±7, massage ±1.
- **Import column rows** cycle through candidate columns on tap.
- **Content reminder toggles** flip per post.
- No elaborate animations — entrance transitions were intentionally removed to keep it calm and instant. Keep transitions minimal (simple color/state changes).

## State Management
Real app should persist server-side; the prototype holds it in component state. Key state:
- `screen` (today | week | contacts | detail | draft | sent | settings | import | content)
- `selectedId` (active contact)
- `filter` (contacts category filter)
- `tone` (warm | short | direct), plus editable `draftSubject` / `draftText`
- `statuses{}` (per-contact status override), `doneFollowups{}`, `doneTasks{}`, `sentInfo`
- Settings: `pushOn`, `emailOn`, `digest`, `cadence{}` (per category, in days)
- Import: `importStep`, `chosenSheet`, `mapOverride{}`
- Content: `remindOff{}` (per post)

### Data fetching / integrations the real app must implement (mocked in prototype)
- **Contacts store** (DB) — fields: name, organization, type, email, phone, first contact, last contact, next follow-up, status, notes, history[].
- **Gmail:** OAuth connect; send drafted email; write sent-date + status back to the contact; detect replies and flag for review.
- **Reminders:** scheduled job that fires push/email when a `nextFollowup` date arrives, respecting the digest time + per-category cadence; cadence is what auto-computes each `nextFollowup` from `lastContact`.
- **AI drafting:** call an LLM with the contact's name/org/history + a voice/tone guide to generate the email; the three tone presets map to instructions. Always return an editable draft; never auto-send.
- **Google Sheets import:** OAuth; list sheets; read columns + rows; column mapping; upsert (update existing by email, don't duplicate); one-way read.
- **Content calendar:** posts with platform, scheduled datetime, status, reminder flag; reminder notifications when post time approaches.

## Assets
All in this bundle's `assets/` folder, derived from the founder's real brand:
- `logo.png` — "next level skincare" green wordmark, transparent background (knocked out from the original white-bg PNG). Used in Today header.
- `product-hero.png` — product jar on cream with calendula/lavender (homepage-style hero). Used in the Today empty state.
- `product-jar.png` — 360×360 square crop of the jar. Used as the Draft-screen thumbnail and Content post thumbnails.
- Icons are inline SVG (feather-style stroke icons) — reproduce with the codebase's icon set (e.g. lucide/feather).
- Fonts: **Cormorant Garamond** + **Mulish** (Google Fonts).

## Files
- `Operations Manager.dc.html` — the full prototype (all screens + logic). Authored in an in-house template runtime; **read it as a spec**, not as code to port verbatim. The markup shows exact layout/styles/copy; the `class Component` logic block shows the data model, draft-generation presets, cadence math, and all interaction handlers.
- `assets/` — brand images listed above.
- `screenshots/` — rendered reference images of every screen (see index below).

## Screenshots index
- `01-today.png` — Today dashboard (greeting, stat pills, "needs you today" cards)
- `02-week.png` — This Week task list, day-grouped with category chips
- `03-contacts.png` — Contacts list with search + category filter chips
- `04-detail.png` — Contact detail (actions, facts grid, status, history, notes)
- `05-draft.png` — AI email draft (tone toggles, editable subject/body, product thumbnail)
- `06-sent.png` — Sent confirmation with auto-log summary
- `07-settings.png` — Settings (reminders toggles, daily digest, notification preview)
- `08-import-1-choose-sheet.png` — Google Sheets import step 1 (choose spreadsheet)
- `09-import-2-map-columns.png` — Import step 2 (column mapping with samples)
- `10-import-3-review.png` — Import step 3 (review counts + reassurances)
- `11-import-4-done.png` — Import step 4 (success)
- `12-content.png` — Content calendar (reminder banner, grouped posts, reminder toggles)

Note: Settings also includes a "Follow-up cadence" section (per-category stepper rows) and an "Import & accounts" section below the visible fold of `07-settings.png` — both are fully specified in the Settings section above.

